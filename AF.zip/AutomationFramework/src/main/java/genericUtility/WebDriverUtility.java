package genericUtility;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebDriverUtility {
	/**
	 * This method is used to maximize the browser provided driver
	 * @param driver
	 */
	public void toMaximize(WebDriver driver) {
		driver.manage().window().maximize();
	}

	/**
	 * This method is used to maximize the browser provided driver
	 * @param driver
	 */
	public void toMinimize(WebDriver driver) {
		driver.manage().window().minimize();
	}
	
	/**
	 * This method will wait until the element gets loaded in webpage (Implicit wait)
	 * @param driver
	 */
	public void waitForElement(WebDriver driver) {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
	}
	
	/**
	 * This method will wait until the element becomes Clickable provided driver and element
	 * @param driver
	 * @param element
	 */
	public void elementToBeClickable(WebDriver driver, WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	
	/**
	 * This method is used to handle dropDown using Index value
	 * @param element
	 * @param index
	 */
	public void toHandleDropdown(WebElement element, int index) {
		Select select = new Select(element);
		select.selectByIndex(index);
	}
	
	/**
	 * This method is used to handle dropDown using value
	 * @param element
	 * @param value
	 */
	public void toHandleDropdown(WebElement element, String value ) {  //Method overloading
		Select select = new Select(element);
		select.selectByValue(value);
	}
	
	/**
	 * This method is used to handle dropDown using visibleText
	 * @param element
	 * @param text
	 */
	public void toHandleDropdown( String text, WebElement element) {  //Method overloading
		Select select = new Select(element);
		select.selectByVisibleText(text);
	}
	
	/**
	 * 
	 * @param driver
	 * @param index
	 */
	public void toHandleFrame(WebDriver driver , int index) {
		driver.switchTo().frame(index);
	}
	
	/**
	 * 
	 * @param driver
	 * @param name_id
	 */
	public void toHandleFrame(WebDriver driver, String name_id) {
		driver.switchTo().frame(name_id);
	}
	
	/**
	 * 
	 * @param driver
	 * @param element
	 */
	public void tohandleFrame(WebDriver driver, WebElement element) {
		driver.switchTo().frame(element);
	}
	
	/**
	 * 
	 * @param driver
	 */
	public void toSwitchBackFromFrame(WebDriver driver) {
		driver.switchTo().defaultContent();
	}
	
	
}
