package Practice_Project;

public class DemoScriptWithGenericUtility {
	//To Read Data from property file
	PropertyFileUtility putil = new PropertyFileUtility();
	putil.
	
	

}
